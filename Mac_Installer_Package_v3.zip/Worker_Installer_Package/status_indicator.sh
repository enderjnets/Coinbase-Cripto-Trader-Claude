#!/bin/bash
#
# 📊 Bittrader Worker Status Indicator
# Shows notifications and status updates for the worker
#

INSTALL_DIR="$HOME/.bittrader_worker"
STATUS_FILE="$INSTALL_DIR/status"
LOG_FILE="$INSTALL_DIR/status.log"

# Load config
source "$INSTALL_DIR/config.env" 2>/dev/null

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

show_notification() {
    local title="$1"
    local message="$2"
    local sound="${3:-default}"
    
    osascript -e "display notification \"$message\" with title \"$title\" sound name \"$sound\"" 2>/dev/null
}

get_status() {
    # Check if Ray process is alive
    if pgrep -x "raylet" > /dev/null; then
        # Basic check: is the raylet process responsive?
        # We avoid ray.init() here as it is very heavy for a 30s loop.
        echo "connected"
    else
        echo "disconnected"
    fi
}

get_cpu_mode() {
    if [ -f "$INSTALL_DIR/current_cpus" ]; then
        local cpus=$(cat "$INSTALL_DIR/current_cpus")
        local max=$(sysctl -n hw.ncpu)
        if [ "$cpus" -eq "$max" ]; then
            echo "full"
        else
            echo "reduced"
        fi
    else
        echo "full"
    fi
}

# Initial notification
show_notification "Bittrader Worker" "Monitor de estado iniciado" "Submarine"
log "📊 Status Indicator iniciado"

last_status="unknown"
last_notification_time=0
NOTIFICATION_COOLDOWN=300  # 5 minutes between repeat notifications

while true; do
    current_status=$(get_status)
    cpu_mode=$(get_cpu_mode)
    current_time=$(date +%s)
    
    # Save status to file for other scripts to read
    echo "$current_status" > "$STATUS_FILE"
    echo "$cpu_mode" >> "$STATUS_FILE"
    
    # Check if status changed
    if [ "$current_status" != "$last_status" ]; then
        case "$current_status" in
            "connected")
                show_notification "Bittrader Worker" "✅ Conectado al cluster" "Glass"
                log "✅ Status: Conectado"
                ;;
            "running_no_cluster")
                show_notification "Bittrader Worker" "⚠️ Ray activo, sin cluster" "Basso"
                log "⚠️ Status: Ray activo pero sin conexión a cluster"
                ;;
            "disconnected")
                # Only notify if not just started
                if [ "$last_status" != "unknown" ]; then
                    show_notification "Bittrader Worker" "🔴 Desconectado - Reconectando..." "Basso"
                    log "🔴 Status: Desconectado"
                fi
                ;;
        esac
        last_status="$current_status"
        last_notification_time=$current_time
    fi
    
    # Periodic status reminder (every 30 minutes if connected)
    time_since_notification=$((current_time - last_notification_time))
    if [ "$current_status" == "connected" ] && [ "$time_since_notification" -gt 1800 ]; then
        # Get job count if possible
        jobs=$(python3 -c "import ray; ray.init(address='auto', ignore_reinit_error=True); print(len(ray.nodes()))" 2>/dev/null || echo "?")
        show_notification "Bittrader Worker" "💚 Activo - $jobs nodos en cluster" "default"
        last_notification_time=$current_time
    fi
    
    sleep 30
done
