═══════════════════════════════════════════════════════════════
       🎁 BITTRADER WORKER - GUÍA DE INSTALACIÓN
═══════════════════════════════════════════════════════════════

¡Gracias por unirte al cluster de procesamiento distribuido!

REQUISITOS:
  • macOS 12 (Monterey) o superior
  • Conexión a internet

═══════════════════════════════════════════════════════════════
PASOS DE INSTALACIÓN
═══════════════════════════════════════════════════════════════

PASO 1: INSTALAR TAILSCALE
---------------------------
1. Abre el link de invitación que te enviaron
2. Crea una cuenta o inicia sesión (puedes usar Google)
3. Acepta unirte a la red

PASO 2: EJECUTAR EL INSTALADOR
-------------------------------
1. Abre Terminal (busca "Terminal" en Spotlight)
2. Navega a esta carpeta:
   
   cd ~/Downloads/Worker_Installer_Package
   
3. Ejecuta el instalador:
   
   bash install.sh
   
4. Ingresa la IP del Head Node cuando se te pida
   (Te la enviará el administrador del cluster)

¡LISTO!
-------
Tu Mac ahora contribuye poder de procesamiento automáticamente.
No necesitas hacer nada más.

═══════════════════════════════════════════════════════════════
INFORMACIÓN ADICIONAL
═══════════════════════════════════════════════════════════════

¿CUÁNTO AFECTA MI MAC?
  • Cuando usas tu Mac: Solo usa 2 CPUs (mínimo impacto)
  • Cuando está idle (5+ min): Usa todos los CPUs

¿CONSUME MUCHA BATERÍA?
  • Solo procesa cuando está conectada a corriente (opcional)
  • Si estás en batería, el impacto es mínimo

¿CÓMO DESINSTALO?
  Ejecuta: bash uninstall.sh

¿DÓNDE VEO LOS LOGS?
  ~/.bittrader_worker/worker.log

═══════════════════════════════════════════════════════════════
CONTACTO
═══════════════════════════════════════════════════════════════

Si tienes problemas, contacta al administrador del cluster.

