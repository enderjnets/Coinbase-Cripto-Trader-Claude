"""
Optimizer Runner - Ejecuta optimización en proceso separado
Permite comunicación bidireccional con Streamlit usando multiprocessing.Queue
"""

import multiprocessing as mp
from multiprocessing import Queue, Process
import pandas as pd
import time
import traceback


def run_optimizer_process(data_dict, param_ranges, risk_level, opt_method,
                          ga_params, progress_queue, result_queue, stop_event):
    """
    Función que corre en un proceso separado.
    Ejecuta la optimización y envía actualizaciones via Queue.

    Args:
        data_dict: DataFrame convertido a dict
        param_ranges: Diccionario de rangos de parámetros
        risk_level: Nivel de riesgo
        opt_method: "grid" o "genetic"
        ga_params: (generations, population, mutation_rate) si es genetic
        progress_queue: Queue para enviar (tipo, mensaje) al UI
        result_queue: Queue para enviar resultado final
        stop_event: Event para señalar detención
    """
    try:
        # Reconstruir DataFrame desde dict of records
        df = pd.DataFrame(data_dict)

        # Log callback que envía a Queue
        def log_cb(msg):
            if not stop_event.is_set():
                progress_queue.put(("log", msg))

        # Progress callback
        def prog_cb(pct):
            if not stop_event.is_set():
                progress_queue.put(("progress", pct))

        # Importar optimizer (dentro del proceso)
        if opt_method == "genetic":
            from optimizer import GeneticOptimizer
            gens, pop, mut = ga_params
            optimizer = GeneticOptimizer(
                population_size=pop,
                generations=gens,
                mutation_rate=mut
            )
        else:
            from optimizer import GridOptimizer
            optimizer = GridOptimizer()

        # Ejecutar optimización
        log_cb("🚀 Iniciando optimización en proceso separado...")

        results = optimizer.optimize(
            df,
            param_ranges,
            risk_level=risk_level,
            progress_callback=prog_cb,
            log_callback=log_cb
        )

        # Enviar resultado
        if not stop_event.is_set():
            # GUARDAR RESULTADO EN DISCO PARA EVITAR SIGSEGV EN QUEUE
            # El DataFrame puede ser muy grande para multiprocessing.Queue en Mac
            import uuid
            
            temp_file = f"temp_opt_results_{uuid.uuid4().hex}.json"
            results.to_json(temp_file, orient='records', indent=2)
            
            # Enviar solo la ruta del archivo
            result_queue.put(("success", temp_file))
            log_cb(f"✅ Optimización completada. Resultados guardados en {temp_file}")
        else:
            result_queue.put(("stopped", None))
            log_cb("⚠️ Optimización detenida por el usuario")

    except Exception as e:
        error_msg = f"❌ Error: {str(e)}\n{traceback.format_exc()}"
        
        # PERSIST CRASH LOG TO FILE
        try:
            with open("OPTIMIZER_CRASH.txt", "w") as f:
                f.write(error_msg)
        except:
            pass
            
        progress_queue.put(("log", error_msg))
        result_queue.put(("error", str(e)))


class OptimizerRunner:
    """
    Gestiona la ejecución del optimizer en un proceso separado.
    """

    def __init__(self):
        self.process = None
        self.progress_queue = None
        self.result_queue = None
        self.stop_event = None
        self.is_running = False

    def start(self, df, param_ranges, risk_level, opt_method="grid", ga_params=(10, 50, 0.1)):
        """
        Inicia la optimización en un proceso separado.

        Returns:
            (progress_queue, result_queue) para leer actualizaciones
        """
        if self.is_running:
            raise RuntimeError("Ya hay una optimización corriendo")

        # Crear queues y event
        self.progress_queue = Queue()
        self.result_queue = Queue()
        self.stop_event = mp.Event()

        # Convertir DataFrame a dict para serialización
        data_dict = df.to_dict('records')

        # Crear y lanzar proceso
        self.process = Process(
            target=run_optimizer_process,
            args=(data_dict, param_ranges, risk_level, opt_method,
                  ga_params, self.progress_queue, self.result_queue, self.stop_event)
        )

        self.process.start()
        self.is_running = True

        return self.progress_queue, self.result_queue

    def stop(self):
        """Solicita detener la optimización."""
        if self.is_running and self.stop_event:
            self.stop_event.set()

    def is_alive(self):
        """Verifica si el proceso sigue corriendo."""
        if self.process:
            return self.process.is_alive()
        return False

    def cleanup(self):
        """Limpia recursos de forma segura."""
        # Cerrar Queues explícitamente para evitar BrokenPipe/Segfault
        try:
            if self.progress_queue:
                self.progress_queue.close()
                self.progress_queue.join_thread()
            if self.result_queue:
                self.result_queue.close()
                self.result_queue.join_thread()
        except:
            pass

        if self.process and self.process.is_alive():
            self.process.terminate()
            self.process.join(timeout=2)

        self.is_running = False
        self.process = None
        self.progress_queue = None
        self.result_queue = None
        self.stop_event = None
