#!/bin/bash
# Script de Restauración Automática
# Sistema de Búsquedas Paralelas
# Fecha del backup: 30 Enero 2026, 23:09

set -e  # Exit on error

echo ""
echo "================================================================================"
echo "🔄 RESTAURACIÓN - SISTEMA DE BÚSQUEDAS PARALELAS"
echo "================================================================================"
echo ""

# Directorio destino
DEST_DIR="/Users/enderj/Library/CloudStorage/GoogleDrive-enderjnets@gmail.com/My Drive/Bittrader/Bittrader EA/Dev Folder/Coinbase Cripto Trader Claude"

# Verificar que estamos en el directorio del backup
if [ ! -f "README_RESTAURACION.md" ]; then
    echo "❌ ERROR: Este script debe ejecutarse desde el directorio del backup"
    echo "   Directorio actual: $(pwd)"
    exit 1
fi

echo "📂 Directorio de destino:"
echo "   $DEST_DIR"
echo ""

# Confirmar con usuario
read -p "¿Deseas continuar con la restauración? (s/n): " confirm
if [ "$confirm" != "s" ] && [ "$confirm" != "S" ]; then
    echo "❌ Restauración cancelada por el usuario"
    exit 0
fi

echo ""
echo "🚀 Iniciando restauración..."
echo ""

# Crear backup de archivos existentes (por si acaso)
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
TEMP_BACKUP="$DEST_DIR/TEMP_BACKUP_PRE_RESTORE_$TIMESTAMP"

if [ -f "$DEST_DIR/run_miner_PRO.py" ]; then
    echo "📦 Creando backup temporal de archivos existentes..."
    mkdir -p "$TEMP_BACKUP"

    cp "$DEST_DIR/run_miner_PRO.py" "$TEMP_BACKUP/" 2>/dev/null || true
    cp "$DEST_DIR/run_miner_AIR.py" "$TEMP_BACKUP/" 2>/dev/null || true
    cp "$DEST_DIR/strategy_miner.py" "$TEMP_BACKUP/" 2>/dev/null || true
    cp "$DEST_DIR/backtester.py" "$TEMP_BACKUP/" 2>/dev/null || true

    echo "   ✅ Backup temporal creado en: $TEMP_BACKUP"
    echo ""
fi

# Restaurar scripts principales
echo "📝 Restaurando scripts principales..."
cp run_miner_PRO.py "$DEST_DIR/"
cp run_miner_AIR.py "$DEST_DIR/"
cp run_miner_NO_RAY.py "$DEST_DIR/"
cp strategy_miner.py "$DEST_DIR/"
cp backtester.py "$DEST_DIR/"
cp dynamic_strategy.py "$DEST_DIR/"
echo "   ✅ Scripts principales restaurados"
echo ""

# Restaurar utilidades
echo "🔧 Restaurando utilidades..."
cp compare_results.py "$DEST_DIR/"
cp monitor_progress.sh "$DEST_DIR/"
chmod +x "$DEST_DIR/monitor_progress.sh"
echo "   ✅ Utilidades restauradas"
echo ""

# Restaurar documentación
echo "📚 Restaurando documentación..."
cp *.md "$DEST_DIR/"
echo "   ✅ Documentación restaurada (34 archivos)"
echo ""

# Restaurar datos
echo "💾 Restaurando datos..."
mkdir -p "$DEST_DIR/data"
cp data/BTC-USD_FIVE_MINUTE.csv "$DEST_DIR/data/"
echo "   ✅ Datos restaurados (3.9 MB)"
echo ""

# Restaurar resultados históricos (opcional)
echo "📊 Restaurando resultados históricos..."
cp *.json "$DEST_DIR/" 2>/dev/null || echo "   ⚠️  Sin resultados JSON para restaurar"
echo ""

# Verificación
echo "🔍 Verificando restauración..."
echo ""

ERRORS=0

if [ ! -f "$DEST_DIR/run_miner_PRO.py" ]; then
    echo "   ❌ ERROR: run_miner_PRO.py no encontrado"
    ERRORS=$((ERRORS + 1))
else
    echo "   ✅ run_miner_PRO.py"
fi

if [ ! -f "$DEST_DIR/run_miner_AIR.py" ]; then
    echo "   ❌ ERROR: run_miner_AIR.py no encontrado"
    ERRORS=$((ERRORS + 1))
else
    echo "   ✅ run_miner_AIR.py"
fi

if [ ! -f "$DEST_DIR/strategy_miner.py" ]; then
    echo "   ❌ ERROR: strategy_miner.py no encontrado"
    ERRORS=$((ERRORS + 1))
else
    echo "   ✅ strategy_miner.py"
fi

if [ ! -f "$DEST_DIR/backtester.py" ]; then
    echo "   ❌ ERROR: backtester.py no encontrado"
    ERRORS=$((ERRORS + 1))
else
    echo "   ✅ backtester.py"
fi

if [ ! -f "$DEST_DIR/compare_results.py" ]; then
    echo "   ❌ ERROR: compare_results.py no encontrado"
    ERRORS=$((ERRORS + 1))
else
    echo "   ✅ compare_results.py"
fi

if [ ! -f "$DEST_DIR/monitor_progress.sh" ]; then
    echo "   ❌ ERROR: monitor_progress.sh no encontrado"
    ERRORS=$((ERRORS + 1))
else
    echo "   ✅ monitor_progress.sh"
fi

if [ ! -f "$DEST_DIR/data/BTC-USD_FIVE_MINUTE.csv" ]; then
    echo "   ❌ ERROR: data/BTC-USD_FIVE_MINUTE.csv no encontrado"
    ERRORS=$((ERRORS + 1))
else
    echo "   ✅ data/BTC-USD_FIVE_MINUTE.csv"
fi

echo ""

if [ $ERRORS -eq 0 ]; then
    echo "================================================================================"
    echo "✅ RESTAURACIÓN COMPLETADA EXITOSAMENTE"
    echo "================================================================================"
    echo ""
    echo "📁 Archivos restaurados en:"
    echo "   $DEST_DIR"
    echo ""
    echo "🎯 Próximos pasos:"
    echo ""
    echo "   1. Navegar al directorio:"
    echo "      cd \"$DEST_DIR\""
    echo ""
    echo "   2. Ejecutar búsqueda en MacBook Pro:"
    echo "      python3 run_miner_PRO.py"
    echo ""
    echo "   3. Ejecutar búsqueda en MacBook Air:"
    echo "      ssh enderj@100.77.179.14 \"cd '$DEST_DIR' && python3 run_miner_AIR.py\""
    echo ""
    echo "   4. Monitorear progreso:"
    echo "      ./monitor_progress.sh"
    echo ""

    if [ -d "$TEMP_BACKUP" ]; then
        echo "💡 NOTA: Se creó un backup temporal de tus archivos anteriores en:"
        echo "   $TEMP_BACKUP"
        echo "   Puedes eliminarlo si la restauración funciona correctamente."
        echo ""
    fi

    echo "================================================================================"
else
    echo "================================================================================"
    echo "❌ RESTAURACIÓN COMPLETADA CON ERRORES"
    echo "================================================================================"
    echo ""
    echo "⚠️  Se encontraron $ERRORS errores durante la restauración"
    echo ""
    echo "🔧 Revisa manualmente los archivos faltantes"
    echo ""

    if [ -d "$TEMP_BACKUP" ]; then
        echo "💡 Puedes recuperar tus archivos anteriores desde:"
        echo "   $TEMP_BACKUP"
        echo ""
    fi

    exit 1
fi
