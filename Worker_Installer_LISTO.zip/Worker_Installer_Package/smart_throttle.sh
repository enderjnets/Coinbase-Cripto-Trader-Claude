#!/bin/bash
#
# 🎚️ Smart CPU Throttle
# Adjusts Ray CPU usage based on user activity
#

INSTALL_DIR="$HOME/.bittrader_worker"
LOG_FILE="$INSTALL_DIR/throttle.log"

# Load config
source "$INSTALL_DIR/config.env" 2>/dev/null || true

# Activate Virtual Environment
if [ -f "$INSTALL_DIR/venv/bin/activate" ]; then
    source "$INSTALL_DIR/venv/bin/activate"
fi

# Settings
IDLE_THRESHOLD=60  # 1 minute (Aggressive Turbo)
MIN_CPUS=2
MAX_CPUS=$(sysctl -n hw.ncpu)
CHECK_INTERVAL=30   # Check every 30 seconds

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

get_idle_time() {
    # Get seconds since last user input (mouse/keyboard)
    ioreg -c IOHIDSystem | awk '/HIDIdleTime/ {print int($NF/1000000000); exit}'
}

current_mode="unknown"

log "🎚️ Smart Throttle iniciado"
log "   Min CPUs: $MIN_CPUS, Max CPUs: $MAX_CPUS"
log "   Umbral idle: ${IDLE_THRESHOLD}s"

while true; do
    idle_seconds=$(get_idle_time)
    
    if [ "$idle_seconds" -gt "$IDLE_THRESHOLD" ]; then
        desired_mode="full"
        desired_cpus=$MAX_CPUS
    else
        desired_mode="reduced"
        desired_cpus=$MIN_CPUS
    fi
    
    # Only act if mode changed
    if [ "$current_mode" != "$desired_mode" ]; then
        log "🔄 Cambiando a modo $desired_mode ($desired_cpus CPUs)"
        
        # Save desired CPUs for daemon to use on next restart
        echo "$desired_cpus" > "$INSTALL_DIR/current_cpus"
        
        # Check if Ray is running
        if pgrep -x "raylet" > /dev/null; then
            log "   Reiniciando Ray con nueva capacidad..."
            ray stop 2>/dev/null
            sleep 3
            
            # Daemon will pick up and reconnect with new CPU count
            # We just need to trigger the restart
        fi
        
        current_mode=$desired_mode
        log "✅ Modo actualizado: $current_mode"
    fi
    
    sleep $CHECK_INTERVAL
done
