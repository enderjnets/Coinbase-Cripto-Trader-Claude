╔═══════════════════════════════════════════════════════════════════════════════╗
║                    BITTRADER WORKER v4.0 - macOS                              ║
║                                                                               ║
║              Distributed Crypto Strategy Mining System                        ║
║                  4000x speedup with Numba JIT                                 ║
╚═══════════════════════════════════════════════════════════════════════════════╝

INSTALLATION
============

1. Extract this folder anywhere on your Mac

2. Open Terminal and navigate to the folder:
   cd Worker_macOS_v4.0

3. Run the installer:
   ./install.sh

4. If you see "permission denied", first run:
   chmod +x install.sh
   Then try again: ./install.sh

5. When prompted, enter the Coordinator URL (you'll receive this from the admin)
   Example: http://192.168.1.100:5001

6. The installer will:
   - Install Homebrew (if needed)
   - Install Python with Numba JIT acceleration
   - Configure optimal workers for your CPU (Intel or Apple Silicon)
   - Setup auto-start when you login


COMMANDS AFTER INSTALLATION
===========================

Start workers:    ~/crypto_worker/start_workers.sh
Stop workers:     ~/crypto_worker/stop_workers.sh
Check status:     ~/crypto_worker/status.sh
View logs:        tail -f /tmp/worker_1.log


REQUIREMENTS
============
- macOS 11+ (Big Sur or newer)
- Works with both Intel and Apple Silicon Macs
- At least 4GB RAM recommended
- Internet connection


WHAT IT DOES
============
This worker contributes computing power to find optimal cryptocurrency trading
strategies using genetic algorithms. The Numba JIT compiler provides massive
speedups (4000x) compared to regular Python.

Your contribution helps discover profitable trading strategies!


TROUBLESHOOTING
===============
1. If you get "permission denied": chmod +x install.sh
2. If workers don't start, check the coordinator URL
3. Run ./status.sh to check worker status
4. Check logs: tail -f /tmp/worker_1.log


UNINSTALL
=========
To remove:
1. Stop workers: ~/crypto_worker/stop_workers.sh
2. Remove autostart: launchctl unload ~/Library/LaunchAgents/com.bittrader.worker.plist
3. Delete folder: rm -rf ~/crypto_worker


CONTACT
=======
For support, contact the system administrator.


Version: 4.0
Build Date: February 2026
