╔═══════════════════════════════════════════════════════════════════════════════╗
║                    BITTRADER WORKER v4.0 - LINUX                              ║
║                                                                               ║
║              Distributed Crypto Strategy Mining System                        ║
║                  4000x speedup with Numba JIT                                 ║
╚═══════════════════════════════════════════════════════════════════════════════╝

INSTALLATION
============

1. Extract this folder anywhere on your Linux system

2. Open terminal and navigate to the folder:
   cd Worker_Linux_v4.0

3. Make the installer executable:
   chmod +x install.sh

4. Run the installer:
   ./install.sh

5. When prompted, enter the Coordinator URL (you'll receive this from the admin)
   Example: http://192.168.1.100:5001

6. The installer will:
   - Install Python dependencies
   - Create virtual environment with Numba JIT
   - Configure optimal number of workers for your CPU
   - Setup auto-start on boot


COMMANDS AFTER INSTALLATION
===========================

Start workers:    ~/crypto_worker/start_workers.sh
Stop workers:     ~/crypto_worker/stop_workers.sh
Check status:     ~/crypto_worker/status.sh
View logs:        tail -f ~/crypto_worker/worker_1.log


REQUIREMENTS
============
- Linux (Ubuntu, Debian, Fedora, Arch, etc.)
- Python 3.10 or higher (will be installed if missing)
- Internet connection
- At least 4GB RAM recommended


WHAT IT DOES
============
This worker contributes computing power to find optimal cryptocurrency trading
strategies using genetic algorithms. The Numba JIT compiler provides massive
speedups (4000x) compared to regular Python.

Your contribution helps discover profitable trading strategies!


TROUBLESHOOTING
===============
1. If workers don't start, check the coordinator URL is correct
2. Run ./status.sh to see if workers are running
3. Check logs in ~/crypto_worker/worker_*.log for errors
4. Make sure your firewall allows outgoing connections


CONTACT
=======
For support, contact the system administrator.


Version: 4.0
Build Date: February 2026
