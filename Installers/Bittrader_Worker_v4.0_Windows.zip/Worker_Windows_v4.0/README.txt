╔═══════════════════════════════════════════════════════════════════════════════╗
║                    BITTRADER WORKER v4.0 - WINDOWS                            ║
║                                                                               ║
║              Distributed Crypto Strategy Mining System                        ║
║                  4000x speedup with Numba JIT                                 ║
╚═══════════════════════════════════════════════════════════════════════════════╝

INSTALLATION (SUPER EASY!)
==========================

1. Extract this folder anywhere

2. Double-click: INSTALL.bat

3. Done! Workers start automatically.


WHAT HAPPENS
============
- Python is installed automatically if needed
- Numba JIT compiler is installed (4000x speedup!)
- Workers are configured for your CPU
- Auto-start is enabled when Windows boots


COMMANDS
========
Location: C:\Users\YourName\crypto_worker\

start.bat   - Start workers
stop.bat    - Stop workers
status.bat  - Check status


REQUIREMENTS
============
- Windows 10 or 11
- Internet connection
- 4GB RAM minimum


TROUBLESHOOTING
===============
1. If "Windows protected your PC" appears:
   Click "More info" then "Run anyway"

2. If PowerShell blocks the script:
   Right-click INSTALL.bat -> Run as Administrator

3. Check logs in: C:\Users\YourName\crypto_worker\worker_1.log


UNINSTALL
=========
1. Run stop.bat
2. Delete the shortcut from:
   C:\Users\YourName\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup
3. Delete folder: C:\Users\YourName\crypto_worker


Version: 4.0
Build: February 2026
